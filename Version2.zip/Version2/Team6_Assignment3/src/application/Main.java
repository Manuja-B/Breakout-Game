package application;
<<<<<<< HEAD

=======
	
>>>>>>> 96e29e312c6d75bc5f4e21d9df50a81cc3a4b9f9
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
<<<<<<< HEAD
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;

import gameobjects.Ball;
import gameobjects.Brick;
import gameobjects.Clock;
import gameobjects.Paddle;
=======
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;
>>>>>>> 96e29e312c6d75bc5f4e21d9df50a81cc3a4b9f9
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextInputDialog;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import javafx.util.Duration;
import objectcommands.PauseCommand;
import objectcommands.ReplayCommand;
import objectcommands.ResumeCommand;
import objectcommands.StartCommand;
import objectcommands.UndoCommand;
import objectcommands.UpdateCommand;
import savegame.SaveLayout;

public class Main extends Application {


<<<<<<< HEAD
	private Ball ball = new Ball();
	private Paddle paddle = new Paddle();
	private Clock clock = new Clock();
	private Brick brick = new Brick();

	private BorderPane borderPane = new BorderPane();
	private GridPane gridPane = new GridPane();
	private Pane pane = new Pane();
	
	private Button startButton = new Button("Start / Restart");
	private Button pauseButton = new Button(" Pause ");
	private Button resumeButton = new Button("Resume");
	private Button replayButton = new Button("Replay");
	private Button undoButton = new Button("Undo");
	private Button changeLayout = new Button("Change Layout");
	private Button saveButton = new Button("Save");
	private Button loadButton =new Button("Load");
	private HBox buttonHBox = new HBox();
	private Text gameOverText = new Text(100, 150, "GAME OVER!");
	
	private Timeline timeline;
	private Timeline replayTimeline; // The timeline used for replay button.

	private StartCommand startCommand = new StartCommand(ball, paddle, clock, brick);
	private UpdateCommand updateCommand = new UpdateCommand(ball, paddle, clock, brick);
	private PauseCommand pauseCommand = new PauseCommand(ball, paddle, clock, brick);
	private ResumeCommand resumeCommand = new ResumeCommand(ball, paddle, clock, brick);
	private ReplayCommand replayCommand = new ReplayCommand(ball, paddle, clock, brick);
	private UndoCommand undoCommand = new UndoCommand(ball, paddle, clock, brick);
	boolean layflag=false;

	
	/**
	 * This method sets the GUI for the game.
	 * @param primaryStage - the javafx.stage.Stage which is currently running in the game instance.
	 */
=======
    private Ball ball = new Ball();
    private Paddle paddle = new Paddle();
    private Clock clock = new Clock();
    private Brick brick = new Brick();
    
    private Queue<List<Double>> ballqueue = new LinkedList<>();
    private Queue<Double> batqueue = new LinkedList<>();
	
    
    private BorderPane borderPane = new BorderPane();
    private GridPane gridPane = new GridPane();
    private Pane pane = new Pane();
    private Button startButton = new Button("Start / Restart");
    private Button pauseButton = new Button(" Pause ");
    private Button resumeButton = new Button("Resume");
    private Button replayButton = new Button("Replay");
    private Button undoButton = new Button("Undo");
    private Button changeLayout = new Button("Change Layout");
    private Button saveButton = new Button("Save");
    private Button loadButton =new Button("Load");
    private HBox buttonHBox = new HBox();
    private Text gameOverText = new Text(100, 150, "GAME OVER!");
    private TextInputDialog messageBox;
    //private Border border = new Border(new BorderStroke(Paint.valueOf("black"), BorderStrokeStyle.SOLID, CornerRadii.EMPTY, new BorderWidths(1)));
    private Timeline timeline;
    private Timeline replayTimeline; // The timeline used for replay button
    
    private StartCommand startCommand = new StartCommand(ball, paddle, clock, brick);
    private UpdateCommand updateCommand = new UpdateCommand(ball, paddle, clock, brick);
    private PauseCommand pauseCommand = new PauseCommand(ball, paddle, clock, brick);
    private ResumeCommand resumeCommand = new ResumeCommand(ball, paddle, clock, brick);
    private ReplayCommand replayCommand = new ReplayCommand(ball, paddle, clock, brick);
    private UndoCommand undoCommand = new UndoCommand(ball, paddle, clock, brick);
    Boolean layflag=false;
    
>>>>>>> 96e29e312c6d75bc5f4e21d9df50a81cc3a4b9f9
	@Override
	public void start(Stage primaryStage) {
		pane.getChildren().add(ball.getCircle());
		pane.getChildren().add(paddle.getRectangle());
		pane.getChildren().add(brick.getRectangle());
		pane.setMaxHeight(350);
		startButton.setFont(Font.font("Verdana", FontWeight.BOLD, 12));
		pauseButton.setFont(Font.font("Verdana", FontWeight.BOLD, 12));
		resumeButton.setFont(Font.font("Verdana", FontWeight.BOLD, 12));
		replayButton.setFont(Font.font("Verdana", FontWeight.BOLD, 12));
		undoButton.setFont(Font.font("Verdana", FontWeight.BOLD, 12));
		changeLayout.setFont(Font.font("Verdana", FontWeight.BOLD, 12));
		saveButton.setFont(Font.font("Verdana", FontWeight.BOLD, 12));
		loadButton.setFont(Font.font("Verdana", FontWeight.BOLD, 12));


		buttonHBox.getChildren().addAll(startButton, pauseButton, resumeButton, replayButton, undoButton, changeLayout, saveButton, loadButton);
		buttonHBox.setSpacing(2);

		borderPane.setCenter(pane);
		borderPane.setBottom(clock.getClockLabel());

		topPane();
	
		Scene scene = new Scene(borderPane, 700, 700);
		primaryStage.setTitle("                                            DIAMOND SAVER");
		primaryStage.initStyle(StageStyle.UTILITY);
		primaryStage.setScene(scene);
		primaryStage.show();

		ball.getClockFromMain(clock);
		clock.setLabel(clock.getClockLabel());

		gameOverText.setFont(Font.font("Verdana", FontWeight.BOLD, 30));


		timeline = new Timeline(new KeyFrame(Duration.millis(15), (ActionEvent event) -> {
			updateCommand.execute();
			if (ball.collideWith(paddle.getRectangle())) {
				ball.setSpeedY(ball.getSpeedY() * -1);
			}
			if (ball.collideWith(brick.getRectangle())) {
				brick.explode();
				pane.getChildren().add(gameOverText);
				pauseButton.setDisable(true);
				timeline.stop();

			}
		}));
		timeline.setCycleCount(Timeline.INDEFINITE);
		setButtonActions(primaryStage, scene);

	}
	
	
	/**
	 * This method sets the actions for all the buttons in the game.
	 * @param primaryStage - the javafx.stage.Stage which is currently running in the game instance.
	 * @param scene - javafx.scene.Scene which is currently running in the game instance. 	
	 */
	public void setButtonActions(Stage primaryStage, Scene scene)
	{
		pauseButton.setDisable(true);
		resumeButton.setDisable(true);
		replayButton.setDisable(true);
		undoButton.setDisable(true);

		changeLayout.setOnAction(new EventHandler<ActionEvent>() { 
			public void handle(ActionEvent e) 
			{ 
				if (!layflag) {
					layoutPane();
					layflag = !layflag;
				}
				else {
					gridPane.getChildren().clear();
					topPane();
					layflag = !layflag;
				}
			}
		});

		
<<<<<<< HEAD
		startButton.setOnAction(e-> {				
			if (replayTimeline != null) // check if replay timeline is not null, stop it
				replayTimeline.stop();
			pane.setDisable(false);
			pane.getChildren().remove(gameOverText);
			startCommand.execute();
			timeline.playFromStart();
			pauseButton.setDisable(false);
=======
			
			
			buttonHBox.getChildren().addAll(startButton, pauseButton, resumeButton, replayButton, undoButton, changeLayout, saveButton, loadButton);
			buttonHBox.setSpacing(2);

			
			//borderPane.setTop(gridPane);
			borderPane.setCenter(pane);
        	borderPane.setBottom(clock.getClockLabel());
			
			
			topPane();
			 changeLayout.setOnAction(new EventHandler<ActionEvent>() { 
		            public void handle(ActionEvent e) 
		            { 
		            	if (!layflag) {
		            	//controllerPane
		            		//controllerPane.setMinHeight(20);
		            		//gridPane.setStyle("-fx-background-color: #336699;");
		            		rightPane();
		            		//layoutPane();
		            		layflag = !layflag;
		        		}
		        		else {
		        			//controllerPane.setMinHeight(20);
		        			//gridPane.setStyle("-fx-background-color: #336699;");
		        			gridPane.getChildren().clear();
		        			topPane();
		        			layflag = !layflag;
		        		}
		            }
			 });
			
			
			//gridPane.add(startButton, 1, 0);
			//gridPane.add(pauseButton, 2, 0);
			//gridPane.add(resumeButton, 3, 0);
			//gridPane.add(replayButton, 4, 0);
			//gridPane.add(undoButton, 5, 0);
			
	        Scene scene = new Scene(borderPane, 700, 700);
	        primaryStage.setTitle("                                     Diamond Saver ^o^");
	        primaryStage.initStyle(StageStyle.UTILITY);
	        primaryStage.setScene(scene);
			primaryStage.show();
			
			ball.getClockFromMain(clock);
			clock.setLabel(clock.getClockLabel());
			
			gameOverText.setFont(Font.font("Verdana", FontWeight.BOLD, 30));

			pauseButton.setDisable(true);
>>>>>>> 96e29e312c6d75bc5f4e21d9df50a81cc3a4b9f9
			resumeButton.setDisable(true);
			replayButton.setDisable(true);
			undoButton.setDisable(true);

		}); 

		pauseButton.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent e) {
				if (replayTimeline != null) // check if replay timeline is not null, stop it
					replayTimeline.stop();
				pane.setDisable(true);
				pauseCommand.execute();
				timeline.pause();
				resumeButton.setDisable(false);
				replayButton.setDisable(false);
				undoButton.setDisable(false);
			}
		}); 

		resumeButton.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent e) {
				if (replayTimeline != null) // check if replay timeline is not null, stop it
					replayTimeline.stop();
				pane.setDisable(false);
				resumeCommand.execute();
				timeline.play();
				pauseButton.setDisable(false);
				resumeButton.setDisable(true);
				replayButton.setDisable(true);
				undoButton.setDisable(true);
<<<<<<< HEAD
			}
		});

		saveButton.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent e) {
				saveGame();
			}
		});

		loadButton.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent e) {
				loadGame(primaryStage);
			}
		});

		replayButton.setOnAction(new EventHandler<ActionEvent>(){
			@Override
			public void handle(ActionEvent e) {
				Stage secondStage = new Stage();
				BorderPane secondBorderPane = new BorderPane();
				Pane secondPane = new Pane();
				Text replayingText = new Text(60, 80, "REPLAYING");
				replayingText.setFont(Font.font("Verdana", FontWeight.BOLD, 40));
				replayingText.setFill(Color.GRAY);
				secondPane.getChildren().add(ball.getCircle());
				secondPane.getChildren().add(paddle.getRectangle());
				secondPane.getChildren().add(brick.getRectangle());
				secondPane.getChildren().add(replayingText);
				//secondPane.setBorder(border);
				secondBorderPane.setCenter(secondPane);
				secondBorderPane.setTop(clock.getClockLabel());

				Scene secondScene = new Scene(secondBorderPane, 700, 700);
				secondStage.setScene(secondScene);
				secondStage.setTitle("Replaying");
				secondStage.show();
				pane.getChildren().remove(gameOverText);

				replayTimeline = new Timeline(new KeyFrame(Duration.millis(15), new EventHandler<ActionEvent>() {
					@Override
					public void handle(final ActionEvent t) {
						pane.setDisable(false);
						replayCommand.execute();
					}
				}));
				int queueSize = ball.getReplayQueueSize();
				replayTimeline.setCycleCount(queueSize);
				replayTimeline.play();

				// Close the replaying window and recover the primary stage
				secondStage.setOnCloseRequest(event -> {
					replayTimeline.stop();
					pane.getChildren().add(ball.getCircle());
					pane.getChildren().add(paddle.getRectangle());
					pane.getChildren().add(brick.getRectangle());
					borderPane.setCenter(pane);
					borderPane.setBottom(clock.getClockLabel());
					borderPane.setTop(gridPane);
					primaryStage.setScene(scene);
					primaryStage.show();
				});
			}
		});

		undoButton.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent e) {
				undoCommand.execute();
				pauseButton.setDisable(true);
				int queueSize = ball.getReplayQueueSize();
				if (queueSize == 0) 
					replayButton.setDisable(true);
			}
		}); 

	}
	
	
	/**
	 * Sets layout of the game.
	 */
	public  void layoutPane() {
		gridPane.setStyle("-fx-background-color: #FFEBCD;");
		gridPane.getChildren().clear();
		gridPane.add(pauseButton, 7, 0);
		gridPane.add(replayButton, 6, 1);
		gridPane.add(undoButton, 8, 1);
		gridPane.add(resumeButton, 7, 2);
		gridPane.add(startButton, 3, 4);
		gridPane.add(changeLayout, 19, 4);
		gridPane.add(saveButton, 4, 4);
		gridPane.add(loadButton, 18, 4);
		borderPane.setTop(gridPane);

	}
	
	
	/**
	 * Sets layout of the game.
	 */
	public  void topPane() {
		gridPane.setStyle("-fx-background-color: #FFEBCD;");
		gridPane.add(saveButton, 1, 0);
		gridPane.add(pauseButton, 2, 0);
		gridPane.add(loadButton, 3, 0);
		gridPane.add(undoButton, 4, 0);
		gridPane.add(replayButton, 5, 0);
		gridPane.add(changeLayout, 6, 0);
		gridPane.add(startButton, 7, 0);
		gridPane.add(resumeButton, 8, 0);
		borderPane.setTop(gridPane);

	}
	
	
	/**
	 * Saves the instance of SaveLayout in the file system.
	 */

	public void saveGame()
	{
		Object[] batlist= paddle.getReplayQueue().toArray();
		Object[] balllist= ball.getReplayQueue1().toArray();
		// int size=batlist.length;

		double batX = (double) batlist[batlist.length - 1];
		
		List<Double> lastBallCords = (List<Double>) balllist[balllist.length-1];
		double ballX = lastBallCords.get(0);
		double ballY = lastBallCords.get(1);
		double time = lastBallCords.get(2);


		
		SaveLayout sl = new SaveLayout(ballX, ballY, batX, time);
		DateTimeFormatter dtf1 = DateTimeFormatter.ofPattern("HH:mm:ss");  
		LocalDateTime now = LocalDateTime.now(); 
		String filename = dtf1.format(now);
		filename = filename.replace(':', '-');
		System.out.println(filename);
		try
		{
			FileOutputStream fos = new FileOutputStream("C:/Users/manuj/Desktop/test/"+filename);
			ObjectOutputStream oos = new ObjectOutputStream(fos);
			oos.writeObject(sl);    
			oos.close();
			fos.close();
		}
		catch (IOException ioe)
		{
			ioe.printStackTrace();
			return;
		}

	}

	
	/**
	 * Loads the game stored previously in the file system.
	 * @param Stage - the object of javafx.stage.Stage that we are currently using to load the game  back in same stage.
	 */
	public void loadGame(Stage primaryStage) 
	{
		if(pane.getChildren().contains(gameOverText))
		{
			pane.getChildren().remove(gameOverText);
		}
		FileChooser  fileChooser = new FileChooser();
		File selectedFile = fileChooser.showOpenDialog(primaryStage);

		try(ObjectInputStream ois = new ObjectInputStream(new FileInputStream(selectedFile)))
		{
			SaveLayout sl1 = (SaveLayout)ois.readObject();
			ball.setBallCenterX(sl1.getBallX());
			ball.setBallCenterY(sl1.getBallY());
			clock.setTime(sl1.getTime());
			paddle.setPaddleX(sl1.getBatX());
			pane.setDisable(false);
			//resumeCommand.execute();
			timeline.play();
			pauseButton.setDisable(false);
			resumeButton.setDisable(true);
			replayButton.setDisable(true);
			undoButton.setDisable(true);
			brick.getBrickRectangle().setFill(Color.GRAY);
		}
		catch (IOException ioe)
		{
			ioe.printStackTrace();
			return;
		} catch (ClassNotFoundException e1) {
			e1.printStackTrace();
		}
	}

	
=======
					
			}); 
	      
			pauseButton.setOnAction(new EventHandler<ActionEvent>() {
				@Override
				public void handle(ActionEvent e) {
					if (replayTimeline != null) // check if replay timeline is not null, stop it
						replayTimeline.stop();
					pane.setDisable(true);
					pauseCommand.execute();
					timeline.pause();
					resumeButton.setDisable(false);
					replayButton.setDisable(false);
					undoButton.setDisable(false);
				}
			}); 
			
			resumeButton.setOnAction(new EventHandler<ActionEvent>() {
				@Override
				public void handle(ActionEvent e) {
					if (replayTimeline != null) // check if replay timeline is not null, stop it
						replayTimeline.stop();
					pane.setDisable(false);
					resumeCommand.execute();
					timeline.play();
					pauseButton.setDisable(false);
					resumeButton.setDisable(true);
					replayButton.setDisable(true);
					undoButton.setDisable(true);
				}
			});
			
			saveButton.setOnAction(new EventHandler<ActionEvent>() {
				@Override
				public void handle(ActionEvent e) {
					//messageBox = new TextInputDialog("Enter FileName");
					//messageBox.show();
					//Optional<String> filename = messageBox.showAndWait();
					//System.out.println(filename);
					//System.out.println(filename.get());
					  // LocalDateTime now = LocalDateTime.now();  
					  // System.out.println(now);
					
					//if(filename.isPresent())
					//{
						SaveLayout sl = new SaveLayout(ball.getReplayQueue1(),paddle.getReplayQueue());
						try
				        {
							FileOutputStream fos = new FileOutputStream("C:\\Users\\saira\\Desktop\\OOSD\\Atari\\test"+System.currentTimeMillis());
							//FileOutputStream fos = new FileOutputStream("/Users/juhi/Desktop/OOSD/test.txt");
				            ObjectOutputStream oos = new ObjectOutputStream(fos);
				            oos.writeObject(sl);    
				            oos.close();
				            fos.close();
				        }
				        catch (IOException ioe)
				        {
				            ioe.printStackTrace();
				            return;
				        }
					//}
					
					
				
				}
			});
			
			loadButton.setOnAction(new EventHandler<ActionEvent>() {
				@Override
				public void handle(ActionEvent e) {
					if(pane.getChildren().contains(gameOverText))
					{
						pane.getChildren().remove(gameOverText);
					}
					FileChooser  fileChooser = new FileChooser();
					 File selectedFile = fileChooser.showOpenDialog(primaryStage);
					
					//SaveLayout sl = new SaveLayout(ball.getReplayQueue1(),ball.getReplayQueue2());
 					try(ObjectInputStream ois = new ObjectInputStream(new FileInputStream(selectedFile)))
			        {
						
			            
			            SaveLayout sl1 = (SaveLayout)ois.readObject();
			          
			            batqueue = sl1.getBatqueue();
			            ballqueue = sl1.getBallqueue();
			           // System.out.println(replayQueue);
			           Object[] batlist= batqueue.toArray();
			           Object[] balllist= ballqueue.toArray();
			          // int size=batlist.length;
			           
			           double batLastCord = (double) batlist[batlist.length - 1];
			           
			          int sizeb=balllist.length;
			           
			           
			        //   System.out.println(alist[size-1] instanceof List );
			            
			            @SuppressWarnings("unchecked")
						List<Double> lastBallCords = (List<Double>) balllist[sizeb-1];
			            //List<Double> lastItemP = (List<Double>) blist[sizeb-1];
			            System.out.println(lastBallCords);
			            
			            ball.setBallCenterX(lastBallCords.get(0));
			            ball.setBallCenterY(lastBallCords.get(1));
			            clock.setTime(lastBallCords.get(2));
			            paddle.setPaddleX(batLastCord);
			            pane.setDisable(false);
						//resumeCommand.execute();
						timeline.play();
						pauseButton.setDisable(false);
						resumeButton.setDisable(true);
						replayButton.setDisable(true);
						undoButton.setDisable(true);
						brick.getBrickRectangle().setFill(Color.GRAY);
						
			            
			            
			        }
			        catch (IOException ioe)
			        {
			            ioe.printStackTrace();
			            return;
			        } catch (ClassNotFoundException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
 					
				}
			});
			
			replayButton.setOnAction(new EventHandler<ActionEvent>(){
				@Override
				public void handle(ActionEvent e) {
					Stage secondStage = new Stage();
					BorderPane secondBorderPane = new BorderPane();
					Pane secondPane = new Pane();
					Text replayingText = new Text(60, 80, "REPLAYING");
					replayingText.setFont(Font.font("Verdana", FontWeight.BOLD, 40));
					replayingText.setFill(Color.GRAY);
					secondPane.getChildren().add(ball.getCircle());
					secondPane.getChildren().add(paddle.getRectangle());
					secondPane.getChildren().add(brick.getRectangle());
					secondPane.getChildren().add(replayingText);
					//secondPane.setBorder(border);
					secondBorderPane.setCenter(secondPane);
					secondBorderPane.setTop(clock.getClockLabel());
				
					Scene secondScene = new Scene(secondBorderPane, 700, 700);
					secondStage.setScene(secondScene);
					secondStage.setTitle("Replaying");
					secondStage.show();
					pane.getChildren().remove(gameOverText);
					
					replayTimeline = new Timeline(new KeyFrame(Duration.millis(15), new EventHandler<ActionEvent>() {
			            @Override
			            public void handle(final ActionEvent t) {
			            	pane.setDisable(false);
			            	replayCommand.execute();
			            }
			        }));
					int queueSize = ball.getReplayQueueSize();
					replayTimeline.setCycleCount(queueSize);
					replayTimeline.play();
					
					// Close the replaying window and recover the primary stage
					secondStage.setOnCloseRequest(event -> {
						replayTimeline.stop();
						pane.getChildren().add(ball.getCircle());
						pane.getChildren().add(paddle.getRectangle());
						pane.getChildren().add(brick.getRectangle());
						borderPane.setCenter(pane);
						borderPane.setBottom(clock.getClockLabel());
						borderPane.setTop(gridPane);
						primaryStage.setScene(scene);
						primaryStage.show();
						});
				}
			});
			
			undoButton.setOnAction(new EventHandler<ActionEvent>() {
				@Override
				public void handle(ActionEvent e) {
					undoCommand.execute();
					pauseButton.setDisable(true);
					int queueSize = ball.getReplayQueueSize();
					if (queueSize == 0) 
						replayButton.setDisable(true);
				}
			}); 
		            }
		            public  void rightPane() {
		            	//borderPane.setCenter(pane);
			           // borderPane.setTop(clock.getClockLabel());
			            //gridPane.setHgap(2);
			            //gridPane.setVgap(2);
			            //gridPane.setPadding(new Insets(0,10,0,10));
		            	gridPane.setStyle("-fx-background-color: #FFEBCD;");
		            	gridPane.getChildren().clear();
			           	gridPane.add(pauseButton, 7, 0);
			        	gridPane.add(replayButton, 6, 1);
			        	gridPane.add(undoButton, 8, 1);
			        	gridPane.add(resumeButton, 7, 2);
			        	gridPane.add(startButton, 3, 4);
			        	gridPane.add(changeLayout, 19, 4);
			        	gridPane.add(saveButton, 4, 4);
			        	gridPane.add(loadButton, 18, 4);
			        	borderPane.setTop(gridPane);
		        	
		            }
		            public  void layoutPane() {
		            	//borderPane.getChildren().clear();
		           // gridPane.getChildren().clear();
		            borderPane.setCenter(pane);
		            borderPane.setTop(clock.getClockLabel());
		            //gridPane.setHgap(2);
		            //gridPane.setVgap(2);
		            //gridPane.setPadding(new Insets(0,10,0,10));
		           	gridPane.add(pauseButton, 2, 0);
		        	gridPane.add(replayButton, 1, 1);
		        	gridPane.add(undoButton, 3, 1);
		        	gridPane.add(resumeButton, 2, 3);
		        	gridPane.add(startButton, 0, 4);
		        	gridPane.add(changeLayout, 1, 4);
		        	gridPane.add(saveButton, 2, 4);
		        	gridPane.add(loadButton, 2, 4);
		        	borderPane.setBottom(gridPane);
		        	
		        	
		            }
		            public  void topPane() {
		            	//borderPane.getChildren().clear();
		            	//borderPane.setCenter(pane);
		            	//borderPane.setBottom(clock.getClockLabel());
		            	gridPane.setStyle("-fx-background-color: #FFEBCD;");
			           	gridPane.add(saveButton, 1, 0);
			        	gridPane.add(pauseButton, 2, 0);
			        	gridPane.add(loadButton, 3, 0);
			        	gridPane.add(undoButton, 4, 0);
			        	gridPane.add(replayButton, 5, 0);
			        	gridPane.add(changeLayout, 6, 0);
			        	gridPane.add(startButton, 7, 0);
			        	gridPane.add(resumeButton, 8, 0);
			        	borderPane.setTop(gridPane);
			        	
			            }
			
>>>>>>> 96e29e312c6d75bc5f4e21d9df50a81cc3a4b9f9
	public static void main(String[] args) {
		launch(args);
	}
}
